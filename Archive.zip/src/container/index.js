export const TOKEN = "PORTFOLIO_TOKEN";
export const ENDPOINT = "https://ap-portfolio-backend.up.railway.app/";
